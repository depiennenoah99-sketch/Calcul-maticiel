// -------------------- Modèle mathématique --------------------
// Les points sont des vecteurs-colonnes homogènes [x, y, 1]ᵀ.
// Chaque transformation est une matrice 3×3. Pour appliquer T1 puis T2,
// la matrice composée est M = T2 × T1 (la nouvelle matrice est à gauche).

const $ = (id) => document.getElementById(id);
const canvas = $("graph"), ctx = canvas.getContext("2d");
let original = [[-2,-1],[2,-1],[1,2],[-1,1]];
let current = original.map(p => [...p]);
let totalMatrix = identity();
let history = [];

function identity() { return [[1,0,0],[0,1,0],[0,0,1]]; }
function multiply(A, B) {
  return A.map((row, i) => B[0].map((_, j) =>
    row.reduce((sum, value, k) => sum + value * B[k][j], 0)));
}
function applyMatrix(M, point) {
  const v = [point[0], point[1], 1];
  const result = M.map(row => row.reduce((sum, value, i) => sum + value * v[i], 0));
  return [result[0] / result[2], result[1] / result[2]];
}
function matrixFor(type, values) {
  const k = values.k, a = values.a, b = values.b;
  switch (type) {
    case "scaleX": return [[k,0,0],[0,1,0],[0,0,1]];
    case "scaleY": return [[1,0,0],[0,k,0],[0,0,1]];
    case "translation": return [[1,0,a],[0,1,b],[0,0,1]];
    case "reflectX": return [[1,0,0],[0,-1,0],[0,0,1]];
    case "reflectY": return [[-1,0,0],[0,1,0],[0,0,1]];
    case "rotate90": return [[0,-1,0],[1,0,0],[0,0,1]];
    case "rotate180": return [[-1,0,0],[0,-1,0],[0,0,1]];
    case "rotate270": return [[0,1,0],[-1,0,0],[0,0,1]];
    case "homothety": return [[k,0,0],[0,k,0],[0,0,1]];
    default: throw new Error("Transformation inconnue.");
  }
}
const names = {
  scaleX:"Échelle horizontale", scaleY:"Échelle verticale",
  translation:"Translation", reflectX:"Symétrie axe x", reflectY:"Symétrie axe y",
  rotate90:"Rotation 90° antihoraire", rotate180:"Rotation 180° antihoraire",
  rotate270:"Rotation 270° antihoraire", homothety:"Homothétie"
};
function parametersFor(type) {
  const area = $("parameters"); area.innerHTML = "";
  const add = (key, label, value, wide=false) => {
    const wrap = document.createElement("div"); if (wide) wrap.className = "wide";
    const lab = document.createElement("label"); lab.htmlFor = `param-${key}`; lab.textContent = label;
    const input = document.createElement("input"); input.id = `param-${key}`; input.type = "number";
    input.step = "any"; input.value = value; input.required = true;
    wrap.append(lab,input); area.append(wrap);
  };
  if (["scaleX","scaleY","homothety"].includes(type)) add("k","Facteur k", "2", true);
  if (type === "translation") { add("a","Déplacement a", "2"); add("b","Déplacement b", "1"); }
}
function readParameters(type) {
  const read = key => {
    const input = $(`param-${key}`), value = Number(input.value);
    if (!input.value.trim() || !Number.isFinite(value)) throw new Error("Veuillez saisir des paramètres numériques valides.");
    return value;
  };
  if (["scaleX","scaleY","homothety"].includes(type)) return {k:read("k")};
  if (type === "translation") return {a:read("a"),b:read("b")};
  return {};
}
function parsePoints(text) {
  const lines = text.split(/\n/).map(s => s.trim()).filter(Boolean);
  if (lines.length < 3) throw new Error("Un polygone doit contenir au moins trois points.");
  return lines.map((line, i) => {
    const parts = line.split(/[;, \t]+/).filter(Boolean);
    if (parts.length !== 2) throw new Error(`Ligne ${i+1} : utilisez le format x, y.`);
    const point = parts.map(Number);
    if (!point.every(Number.isFinite)) throw new Error(`Ligne ${i+1} : coordonnées non numériques.`);
    return point;
  });
}
function formatMatrix(M) {
  return M.map(row => row.map(n => Math.abs(n)<1e-10 ? 0 : Number(n.toFixed(4))));
}
function applyTransformation(type, values) {
  const T = matrixFor(type, values);
  // Composition correcte : T agit après toutes les transformations précédentes.
  totalMatrix = multiply(T, totalMatrix);
  current = current.map(point => applyMatrix(T, point));
  const detail = type === "translation" ? `a = ${values.a}, b = ${values.b}` :
    values.k !== undefined ? `k = ${values.k}` : "";
  history.push({name:names[type], detail, matrix:T});
  render();
}
function renderHistory() {
  const list = $("history"); list.innerHTML = "";
  if (!history.length) {
    const li = document.createElement("li"); li.className="empty"; li.textContent="Aucune transformation appliquée."; list.append(li); return;
  }
  history.forEach((item, i) => {
    const li = document.createElement("li");
    li.textContent = `${item.name}${item.detail ? " ("+item.detail+")" : ""}`;
    list.append(li);
  });
}
function renderMatrix() {
  const display = $("matrixDisplay"); display.innerHTML = "";
  formatMatrix(totalMatrix).forEach(row => row.forEach(value => {
    const cell = document.createElement("div"); cell.className="matrix-cell";
    cell.textContent = String(value); display.append(cell);
  }));
}
function drawPolygon(points, color, fill, transform) {
  if (!points.length) return;
  const coords = points.map(([x,y]) => transform(x,y));
  ctx.beginPath(); ctx.moveTo(...coords[0]);
  coords.slice(1).forEach(p => ctx.lineTo(...p)); ctx.closePath();
  ctx.fillStyle = fill; ctx.fill(); ctx.strokeStyle = color; ctx.lineWidth=2.5; ctx.stroke();
  coords.forEach(([x,y]) => { ctx.beginPath(); ctx.arc(x,y,3.5,0,Math.PI*2); ctx.fillStyle=color; ctx.fill(); });
}
function draw() {
  const rect = canvas.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
  canvas.width = Math.max(1,Math.round(rect.width*dpr)); canvas.height = Math.max(1,Math.round(rect.height*dpr));
  ctx.setTransform(dpr,0,0,dpr,0,0);
  const w=rect.width,h=rect.height, pad=35;
  const all=[...original,...current];
  let minX=Math.min(0,...all.map(p=>p[0])), maxX=Math.max(0,...all.map(p=>p[0]));
  let minY=Math.min(0,...all.map(p=>p[1])), maxY=Math.max(0,...all.map(p=>p[1]));
  let spanX=Math.max(4,maxX-minX), spanY=Math.max(4,maxY-minY);
  const unit=Math.min((w-2*pad)/spanX,(h-2*pad)/spanY);
  const cx=(minX+maxX)/2, cy=(minY+maxY)/2;
  const centerX=w/2-cx*unit, centerY=h/2+cy*unit;
  const screen=(x,y)=>[centerX+x*unit,centerY-y*unit];
  ctx.clearRect(0,0,w,h); ctx.fillStyle="#fbfcff"; ctx.fillRect(0,0,w,h);
  // Grille et graduations entières.
  const left=(pad-centerX)/unit, right=(w-pad-centerX)/unit;
  const bottom=(centerY-(h-pad))/unit, top=(centerY-pad)/unit;
  const startX=Math.ceil(left), endX=Math.floor(right), startY=Math.ceil(bottom), endY=Math.floor(top);
  ctx.lineWidth=1; ctx.strokeStyle="#e9eef5";
  for(let x=startX;x<=endX;x++){const sx=screen(x,0)[0];ctx.beginPath();ctx.moveTo(sx,pad/2);ctx.lineTo(sx,h-pad/2);ctx.stroke();}
  for(let y=startY;y<=endY;y++){const sy=screen(0,y)[1];ctx.beginPath();ctx.moveTo(pad/2,sy);ctx.lineTo(w-pad/2,sy);ctx.stroke();}
  // Axes.
  ctx.strokeStyle="#64748b";ctx.lineWidth=1.5;
  const x0=screen(0,0)[0], y0=screen(0,0)[1];
  ctx.beginPath();ctx.moveTo(0,y0);ctx.lineTo(w,y0);ctx.moveTo(x0,0);ctx.lineTo(x0,h);ctx.stroke();
  ctx.fillStyle="#718096";ctx.font="10px system-ui";ctx.textAlign="center";
  for(let x=startX;x<=endX;x++) if(x!==0) ctx.fillText(x,screen(x,0)[0],Math.min(h-5,Math.max(11,y0+14)));
  ctx.textAlign="right";
  for(let y=startY;y<=endY;y++) if(y!==0) ctx.fillText(y,Math.min(w-5,Math.max(20,x0-7)),screen(0,y)[1]+3);
  ctx.fillText("0",Math.min(w-5,Math.max(15,x0-7)),Math.min(h-5,Math.max(11,y0+14)));
  ctx.textAlign="right";ctx.fillStyle="#42536b";ctx.fillText("x",w-9,Math.min(h-8,Math.max(12,y0-8)));
  ctx.textAlign="left";ctx.fillText("y",Math.min(w-12,Math.max(8,x0+8)),12);
  drawPolygon(original,"#e07843","rgba(224,120,67,.10)",screen);
  drawPolygon(current,"#0e9f91","rgba(14,159,145,.18)",screen);
}
function render(){draw();renderHistory();renderMatrix();}
function resetToOriginal() {
  current=original.map(p=>[...p]); totalMatrix=identity(); history=[]; render();
}
$("transformType").addEventListener("change",e=>parametersFor(e.target.value));
$("applyTransform").addEventListener("click",()=>{
  try { const type=$("transformType").value; applyTransformation(type,readParameters(type)); $("pointError").textContent=""; }
  catch(error){$("pointError").textContent=error.message;}
});
$("updatePolygon").addEventListener("click",()=>{
  try { original=parsePoints($("pointsInput").value); resetToOriginal(); $("pointError").textContent=""; }
  catch(error){$("pointError").textContent=error.message;}
});
$("resetAll").addEventListener("click",()=>{
  resetToOriginal(); $("pointsInput").value=original.map(p=>p.join(", ")).join("\n"); $("pointError").textContent="";
});
$("copyMatrix").addEventListener("click",async()=>{
  const text=formatMatrix(totalMatrix).map(row=>row.join("\t")).join("\n");
  try { await navigator.clipboard.writeText(text); $("copyMatrix").textContent="Matrice copiée ✓"; }
  catch { $("copyMatrix").textContent="Copie non disponible"; }
  setTimeout(()=>{$("copyMatrix").textContent="Copier la matrice";},1600);
});
const demos = {
  triangle: {points:[[-2,-1],[2,-1],[0,2]],steps:[["scaleX",{k:1.5}],["rotate90",{}],["translation",{a:2,b:1}]]},
  quad: {points:[[-2,-1],[2,-1],[2,1],[-2,1]],steps:[["homothety",{k:1.5}],["rotate180",{}]]},
  translationRotation: {points:[[-1,-1],[1,-1],[1,1],[-1,1]],steps:[["translation",{a:3,b:1}],["rotate90",{}]]}
};
document.querySelectorAll("[data-demo]").forEach(button=>button.addEventListener("click",()=>{
  const demo=demos[button.dataset.demo]; original=demo.points.map(p=>[...p]);
  $("pointsInput").value=original.map(p=>p.join(", ")).join("\n"); resetToOriginal();
  demo.steps.forEach(([type,values])=>applyTransformation(type,values));
  $("pointError").textContent="";
}));
window.addEventListener("resize",draw);
parametersFor($("transformType").value);
render();
