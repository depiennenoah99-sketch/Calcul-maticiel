# Visualiseur de transformations matricielles en 2D

## Lancer l'application
1. Téléchargez ou clonez le dépôt.
2. Ouvrez `index.html` dans un navigateur récent (Chrome, Firefox, Edge ou Safari).
3. Saisissez les sommets du polygone dans la zone de gauche, un point par ligne : `x, y`.
4. Cliquez sur **Mettre à jour**, puis choisissez une transformation et ses paramètres.
5. Cliquez sur **Appliquer la transformation**. Les opérations s'enchaînent et le graphique, l'historique et la matrice composée sont actualisés.

Aucune installation ni bibliothèque externe n'est nécessaire.

## Format des points
Chaque ligne contient exactement deux nombres séparés par une virgule, un point-virgule ou un espace. Il faut au moins trois sommets. Les sommets sont reliés dans leur ordre de saisie, puis le dernier est relié au premier.

## Matrices utilisées
Les points sont représentés par des vecteurs-colonnes homogènes :

`P = [x, y, 1]ᵀ`

| Transformation | Matrice |
|---|---|
| Échelle horizontale de facteur k | `[[k,0,0],[0,1,0],[0,0,1]]` |
| Échelle verticale de facteur k | `[[1,0,0],[0,k,0],[0,0,1]]` |
| Translation (a,b) | `[[1,0,a],[0,1,b],[0,0,1]]` |
| Symétrie axe x | `[[1,0,0],[0,-1,0],[0,0,1]]` |
| Symétrie axe y | `[[-1,0,0],[0,1,0],[0,0,1]]` |
| Rotation 90° antihoraire | `[[0,-1,0],[1,0,0],[0,0,1]]` |
| Rotation 180° antihoraire | `[[-1,0,0],[0,-1,0],[0,0,1]]` |
| Rotation 270° antihoraire | `[[0,1,0],[-1,0,0],[0,0,1]]` |
| Homothétie de rapport k | `[[k,0,0],[0,k,0],[0,0,1]]` |

## Composition des transformations
La multiplication matricielle n'est pas commutative. Si l'on applique d'abord `T1`, puis `T2`, alors :

`P' = T2 × T1 × P`

À chaque nouvelle opération, le programme met donc à jour la matrice totale avec `M_totale = T_nouvelle × M_totale`. Les points transformés sont aussi recalculés avec la nouvelle matrice individuelle. La matrice totale affichée permet de vérifier la composition.

### Exemples de démonstration intégrés
Les trois boutons **Démonstrations** chargent un polygone et exécutent une séquence prédéfinie :
- **Triangle · 3 transformations** : échelle horizontale de facteur 1,5, rotation de 90°, puis translation de vecteur (2,1).
- **Quadrilatère · composition** : homothétie de rapport 1,5, puis rotation de 180°.
- **Translation + rotation** : translation de vecteur (3,1), puis rotation de 90° autour de l'origine.

Le bouton **Réinitialiser** restaure le polygone de départ et remet la matrice composée à l'identité.

## Organisation du code
- `index.html` : structure de l'interface et contrôles.
- `style.css` : mise en page et styles adaptatifs.
- `app.js` : calcul matriciel, gestion des transformations, composition, historique et dessin Canvas.

## Choix techniques
- Les calculs sont séparés du rendu graphique.
- `multiply(A, B)` effectue la multiplication de deux matrices 3×3.
- `applyMatrix(M, point)` multiplie une matrice par un vecteur-colonne homogène.
- Le Canvas dessine une grille, les axes gradués, le polygone initial et le polygone transformé.
- Le cadrage est calculé à partir de l'ensemble des sommets originaux et transformés pour les conserver à l'écran.

## Tests conseillés
1. Triangle `(0,0)`, `(2,0)`, `(0,1)` puis rotation 90° : le point `(2,0)` devient `(0,2)`.
2. Point `(1,2)` puis symétrie axe x : il devient `(1,-2)`.
3. Point `(1,2)` puis translation `(3,-1)` : il devient `(4,1)`.
4. Translation `(3,1)` puis rotation 90° : un point initial `(1,0)` devient `(-1,4)`. Cela illustre que l'ordre des opérations compte.

## Limites
L'application suppose, conformément au sujet, que les points saisis forment un polygone valide. Elle ne vérifie pas la convexité ni l'auto-intersection.
